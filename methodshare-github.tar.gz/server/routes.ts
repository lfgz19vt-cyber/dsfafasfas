import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMethodSchema } from "@shared/schema";
import { z } from "zod";
import passport from "passport";
import { Strategy as DiscordStrategy } from "passport-discord";
import session from "express-session";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-session-secret-here',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // Set to true in production with HTTPS
  }));

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Discord OAuth Strategy
  passport.use(new DiscordStrategy({
    clientID: process.env.DISCORD_CLIENT_ID || '',
    clientSecret: process.env.DISCORD_CLIENT_SECRET || '',
    callbackURL: process.env.DISCORD_CALLBACK_URL || 'https://0ae64524-216d-41d2-9104-858d302b6f98-00-17goaz7qqxtad.worf.replit.dev/api/auth/discord/callback',
    scope: ['identify', 'guilds']
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      // Check if user is in your specific Discord server
      const YOUR_GUILD_ID = process.env.DISCORD_GUILD_ID || 'your_discord_server_id_here';
      
      // Check if user is in the required server
      const isInServer = profile.guilds?.some((guild: any) => guild.id === YOUR_GUILD_ID) || false;
      
      if (!isInServer) {
        return done(null, false, { message: 'User not in required Discord server' });
      }

      // User is verified
      const user = {
        id: profile.id,
        username: profile.username,
        discriminator: profile.discriminator,
        avatar: profile.avatar,
        guilds: profile.guilds
      };
      
      return done(null, user);
    } catch (error) {
      return done(error, false);
    }
  }));

  // Passport serialization
  passport.serializeUser((user: any, done) => {
    done(null, user);
  });

  passport.deserializeUser((user: any, done) => {
    done(null, user);
  });

  // Discord OAuth routes
  app.get('/api/auth/discord', passport.authenticate('discord'));

  app.get('/api/auth/discord/callback',
    passport.authenticate('discord', { failureRedirect: '/promote?error=verification_failed' }),
    (req, res) => {
      // Successful authentication
      res.redirect('/promote?verified=true');
    }
  );

  // Check verification status
  app.get('/api/auth/status', (req, res) => {
    if (req.user) {
      res.json({ 
        isVerified: true, 
        user: req.user 
      });
    } else {
      res.json({ 
        isVerified: false 
      });
    }
  });

  // Logout route
  app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Logout failed' });
      }
      res.json({ message: 'Logged out successfully' });
    });
  });
  // Get all methods
  app.get("/api/methods", async (req, res) => {
    try {
      const methods = await storage.getAllMethods();
      res.json(methods);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch methods" });
    }
  });

  // Search methods
  app.get("/api/methods/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const methods = await storage.searchMethods(query);
      res.json(methods);
    } catch (error) {
      res.status(500).json({ message: "Failed to search methods" });
    }
  });

  // Get methods by category
  app.get("/api/methods/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const methods = await storage.getMethodsByCategory(category);
      res.json(methods);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch methods by category" });
    }
  });

  // Get single method and increment views
  app.get("/api/methods/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const method = await storage.getMethod(id);
      if (!method) {
        return res.status(404).json({ message: "Method not found" });
      }
      await storage.updateMethodViews(id);
      res.json(method);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch method" });
    }
  });

  // Create new method
  app.post("/api/methods", async (req, res) => {
    try {
      const validatedData = insertMethodSchema.parse(req.body);
      const method = await storage.createMethod(validatedData);
      res.status(201).json(method);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid method data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create method" });
    }
  });

  // Update method likes
  app.post("/api/methods/:id/like", async (req, res) => {
    try {
      const { id } = req.params;
      const { increment } = req.body;
      
      if (typeof increment !== 'boolean') {
        return res.status(400).json({ message: "Increment must be a boolean" });
      }

      const method = await storage.getMethod(id);
      if (!method) {
        return res.status(404).json({ message: "Method not found" });
      }

      await storage.updateMethodLikes(id, increment);
      const updatedMethod = await storage.getMethod(id);
      res.json(updatedMethod);
    } catch (error) {
      res.status(500).json({ message: "Failed to update method likes" });
    }
  });

  // Verify Discord server membership
  app.post("/api/verify-discord-member", async (req, res) => {
    try {
      const { username } = req.body;
      
      if (!username || typeof username !== 'string') {
        return res.status(400).json({ message: "Username is required" });
      }

      // Your Discord server/guild ID - replace with your actual server ID
      const YOUR_GUILD_ID = "your_discord_server_id_here";
      
      // In a real implementation, you would:
      // 1. Use Discord API to check if user is in your specific server
      // 2. Use a Discord bot token to access the guild member list
      // 3. Search for the username in your server
      
      // For now, this is a placeholder that you'll need to implement with actual Discord API calls
      // You'll need to install discord.js and implement proper Discord server verification
      
      // Temporary validation - replace with actual Discord API check
      const isValidMember = await checkDiscordServerMembership(username, YOUR_GUILD_ID);
      
      res.json({ 
        isMember: isValidMember,
        message: isValidMember ? "User verified as server member" : "User not found in server"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to verify Discord membership" });
    }
  });

  // Helper function for Discord verification (implement with actual Discord API)
  async function checkDiscordServerMembership(username: string, guildId: string): Promise<boolean> {
    // TODO: Implement actual Discord API verification
    // This would require:
    // 1. Discord bot token
    // 2. discord.js or discord API calls
    // 3. Checking guild member list for the username
    
    // For demo purposes, this simulates the check
    // Replace with actual Discord API implementation
    return username.length > 3 && username !== "test";
  }

  const httpServer = createServer(app);
  return httpServer;
}
