import { type User, type InsertUser, type Method, type InsertMethod } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getMethod(id: string): Promise<Method | undefined>;
  getAllMethods(): Promise<Method[]>;
  searchMethods(query: string): Promise<Method[]>;
  createMethod(method: InsertMethod): Promise<Method>;
  updateMethodViews(id: string): Promise<void>;
  updateMethodLikes(id: string, increment: boolean): Promise<void>;
  getMethodsByCategory(category: string): Promise<Method[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private methods: Map<string, Method>;

  constructor() {
    this.users = new Map();
    this.methods = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMethod(id: string): Promise<Method | undefined> {
    return this.methods.get(id);
  }

  async getAllMethods(): Promise<Method[]> {
    return Array.from(this.methods.values()).sort(
      (a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async searchMethods(query: string): Promise<Method[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.methods.values()).filter(
      (method) =>
        method.title.toLowerCase().includes(lowercaseQuery) ||
        method.description.toLowerCase().includes(lowercaseQuery) ||
        method.category.toLowerCase().includes(lowercaseQuery) ||
        method.author.toLowerCase().includes(lowercaseQuery)
    );
  }

  async createMethod(insertMethod: InsertMethod): Promise<Method> {
    const id = randomUUID();
    const method: Method = {
      ...insertMethod,
      id,
      contentType: insertMethod.contentType || 'text',
      fileUrl: insertMethod.fileUrl || null,
      likes: 0,
      views: 0,
      createdAt: new Date(),
    };
    this.methods.set(id, method);
    return method;
  }

  async updateMethodViews(id: string): Promise<void> {
    const method = this.methods.get(id);
    if (method) {
      method.views = (method.views || 0) + 1;
      this.methods.set(id, method);
    }
  }

  async updateMethodLikes(id: string, increment: boolean): Promise<void> {
    const method = this.methods.get(id);
    if (method) {
      method.likes = Math.max(0, (method.likes || 0) + (increment ? 1 : -1));
      this.methods.set(id, method);
    }
  }

  async getMethodsByCategory(category: string): Promise<Method[]> {
    return Array.from(this.methods.values()).filter(
      (method) => method.category.toLowerCase() === category.toLowerCase()
    );
  }
}

export const storage = new MemStorage();
