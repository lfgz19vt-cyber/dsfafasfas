# 🚀 GitHub + Vercel Deployment Guide

## Quick Setup (5 minutes)

### Step 1: Create GitHub Repository
1. Go to [github.com](https://github.com) and log in
2. Click **"New repository"** (green button)
3. Name it: `methodshare` (or any name you like)
4. Make it **Public** (required for free Vercel)
5. ✅ Check **"Add a README file"**
6. Click **"Create repository"**

### Step 2: Upload Your Code
1. Click **"uploading an existing file"** link
2. Drag and drop these files from your Replit:
   - `server/` folder (entire folder)
   - `client/` folder (entire folder) 
   - `shared/` folder (entire folder)
   - `package.json`
   - `vercel.json` 
   - `.gitignore`
   - `vite.config.ts`
   - `tailwind.config.ts`
   - `tsconfig.json`
   - `drizzle.config.ts`
3. Write commit message: "Initial upload"
4. Click **"Commit changes"**

### Step 3: Deploy to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click **"Sign up"** → **"Continue with GitHub"**
3. Click **"Import Project"**
4. Find your `methodshare` repository
5. Click **"Import"**
6. ✅ Vercel auto-detects everything!
7. Click **"Deploy"**

### Step 4: Add Database (Important!)
1. In Vercel dashboard → **"Storage"** → **"Create Database"**
2. Choose **"Postgres"** → **"Continue"**
3. Name it `methodshare-db` → **"Create"**
4. Go to **"Settings"** → **"Environment Variables"**
5. Vercel auto-adds `DATABASE_URL` ✅

## 🎉 Done! 
Your app will be live at: `https://methodshare-yourusername.vercel.app`

## Alternative: Use Static HTML Version
If you want **FREE hosting with zero setup**:
1. Upload `methodshare-fixed.html` to your GitHub repo
2. Go to **Settings** → **Pages** 
3. Choose **"Deploy from main branch"**
4. Your site: `https://yourusername.github.io/methodshare/methodshare-fixed.html`

---

## Troubleshooting

**Build fails?** Check these files are uploaded:
- ✅ `package.json` 
- ✅ `vercel.json`
- ✅ All `server/`, `client/`, `shared/` folders

**Database errors?** Make sure:
- ✅ Postgres database created in Vercel
- ✅ `DATABASE_URL` environment variable exists

**Need help?** The static HTML version (`methodshare-fixed.html`) always works!