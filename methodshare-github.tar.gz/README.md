# MethodShare - Code Sharing Platform

A full-stack web application for sharing and discovering programming methods, tutorials, and code snippets. Built with React, TypeScript, and Express.js.

## Features

- 📝 Share programming methods and code snippets
- 🔍 Search and filter content by category
- 👍 Like and view tracking for popular content
- 🌙 Dark theme with customizable visual effects
- 📱 Responsive design for all devices
- 🔐 User authentication with Discord OAuth
- ❄️ Optional snowflake animations and visual effects

## Tech Stack

### Frontend
- **React** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** for styling
- **Shadcn/ui** component library
- **TanStack Query** for server state management
- **Wouter** for routing
- **React Hook Form** with Zod validation

### Backend
- **Express.js** with TypeScript
- **Drizzle ORM** with PostgreSQL
- **Session-based authentication**
- **RESTful API design**

## Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/methodshare.git
cd methodshare
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
- Database connection details
- Discord OAuth credentials (optional)
- Session secrets

4. Run the development server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Environment Variables

Create a `.env` file with the following variables:

```env
# Database
DATABASE_URL=your_postgresql_connection_string

# Session
SESSION_SECRET=your_session_secret

# Discord OAuth (optional)
DISCORD_CLIENT_ID=your_discord_client_id
DISCORD_CLIENT_SECRET=your_discord_client_secret
DISCORD_CALLBACK_URL=http://localhost:5000/api/auth/discord/callback
```

## API Endpoints

- `GET /api/methods` - Get all methods
- `GET /api/methods/search?q=query` - Search methods
- `GET /api/methods/category/:category` - Filter by category
- `GET /api/methods/:id` - Get single method
- `POST /api/methods` - Create new method
- `POST /api/methods/:id/like` - Toggle like

## Development

The project uses a monorepo structure with shared types between frontend and backend:

- `/client` - React frontend
- `/server` - Express.js backend
- `/shared` - Shared TypeScript types and schemas

### Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.