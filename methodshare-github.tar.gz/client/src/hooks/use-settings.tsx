import { useState, useEffect, createContext, useContext } from "react";

interface SettingsContextType {
  theme: 'dark' | 'light' | 'auto';
  language: string;
  snowflakesEnabled: boolean;
  animationsEnabled: boolean;
  vfxEnabled: boolean;
  colorScheme: string;
  setTheme: (theme: 'dark' | 'light' | 'auto') => void;
  setLanguage: (language: string) => void;
  setSnowflakesEnabled: (enabled: boolean) => void;
  setAnimationsEnabled: (enabled: boolean) => void;
  setVfxEnabled: (enabled: boolean) => void;
  setColorScheme: (scheme: string) => void;
  resetSettings: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const defaultSettings = {
  theme: 'dark' as const,
  language: 'en',
  snowflakesEnabled: true,
  animationsEnabled: true,
  vfxEnabled: true,
  colorScheme: 'red'
};

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<'dark' | 'light' | 'auto'>(defaultSettings.theme);
  const [language, setLanguage] = useState(defaultSettings.language);
  const [snowflakesEnabled, setSnowflakesEnabled] = useState(defaultSettings.snowflakesEnabled);
  const [animationsEnabled, setAnimationsEnabled] = useState(defaultSettings.animationsEnabled);
  const [vfxEnabled, setVfxEnabled] = useState(defaultSettings.vfxEnabled);
  const [colorScheme, setColorScheme] = useState(defaultSettings.colorScheme);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('methodshare-settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setTheme(parsed.theme || defaultSettings.theme);
        setLanguage(parsed.language || defaultSettings.language);
        setSnowflakesEnabled(parsed.snowflakesEnabled ?? defaultSettings.snowflakesEnabled);
        setAnimationsEnabled(parsed.animationsEnabled ?? defaultSettings.animationsEnabled);
        setVfxEnabled(parsed.vfxEnabled ?? defaultSettings.vfxEnabled);
        setColorScheme(parsed.colorScheme || defaultSettings.colorScheme);
      } catch (error) {
        console.error('Failed to parse saved settings:', error);
      }
    }
  }, []);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    const settings = {
      theme,
      language,
      snowflakesEnabled,
      animationsEnabled,
      vfxEnabled,
      colorScheme
    };
    localStorage.setItem('methodshare-settings', JSON.stringify(settings));
  }, [theme, language, snowflakesEnabled, animationsEnabled, vfxEnabled, colorScheme]);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    
    if (theme === 'auto') {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.className = isDark ? 'dark' : 'light';
    } else {
      root.className = theme;
    }
  }, [theme]);

  // Apply animation preferences
  useEffect(() => {
    if (!animationsEnabled) {
      document.body.style.animationPlayState = 'paused';
      document.body.style.setProperty('*', 'animation-duration: 0.01ms !important');
    } else {
      document.body.style.animationPlayState = 'running';
      document.body.style.removeProperty('*');
    }
  }, [animationsEnabled]);

  const resetSettings = () => {
    setTheme(defaultSettings.theme);
    setLanguage(defaultSettings.language);
    setSnowflakesEnabled(defaultSettings.snowflakesEnabled);
    setAnimationsEnabled(defaultSettings.animationsEnabled);
    setVfxEnabled(defaultSettings.vfxEnabled);
    setColorScheme(defaultSettings.colorScheme);
  };

  return (
    <SettingsContext.Provider
      value={{
        theme,
        language,
        snowflakesEnabled,
        animationsEnabled,
        vfxEnabled,
        colorScheme,
        setTheme,
        setLanguage,
        setSnowflakesEnabled,
        setAnimationsEnabled,
        setVfxEnabled,
        setColorScheme,
        resetSettings,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
