import { useState } from "react";
import { Heart, Eye, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useSettings } from "@/hooks/use-settings";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Method } from "@shared/schema";

interface MethodCardProps {
  method: Method;
}

export default function MethodCard({ method }: MethodCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const { vfxEnabled } = useSettings();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const likeMutation = useMutation({
    mutationFn: async (increment: boolean) => {
      const response = await apiRequest("POST", `/api/methods/${method.id}/like`, { increment });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/methods'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update likes",
        variant: "destructive",
      });
    },
  });

  const handleLike = () => {
    const newLikedState = !isLiked;
    setIsLiked(newLikedState);
    likeMutation.mutate(newLikedState);
  };

  const handleView = async () => {
    try {
      await apiRequest("GET", `/api/methods/${method.id}`);
      queryClient.invalidateQueries({ queryKey: ['/api/methods'] });
    } catch (error) {
      console.error('Failed to update views:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    if (category.toLowerCase() === 'extrnlbeaming') {
      return "fas fa-fire";
    }
    
    // General category icon based on common keywords
    const lowercaseCategory = category.toLowerCase();
    if (lowercaseCategory.includes('program') || lowercaseCategory.includes('code')) return "fas fa-code";
    if (lowercaseCategory.includes('design')) return "fas fa-palette";
    if (lowercaseCategory.includes('tutorial')) return "fas fa-book";
    if (lowercaseCategory.includes('guide')) return "fas fa-map";
    if (lowercaseCategory.includes('backend') || lowercaseCategory.includes('server')) return "fas fa-database";
    if (lowercaseCategory.includes('mobile')) return "fas fa-mobile-alt";
    if (lowercaseCategory.includes('analytic')) return "fas fa-chart-line";
    if (lowercaseCategory.includes('security')) return "fas fa-shield-alt";
    if (lowercaseCategory.includes('web')) return "fas fa-globe";
    if (lowercaseCategory.includes('api')) return "fas fa-plug";
    
    return "fas fa-file";
  };

  const getGradientClass = (category: string) => {
    if (category.toLowerCase() === 'extrnlbeaming') {
      return "from-orange-500 to-red-600";
    }
    
    // Generate gradient based on category name hash for consistent colors
    const lowercaseCategory = category.toLowerCase();
    const hash = lowercaseCategory.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const gradients = [
      "from-primary to-accent",
      "from-secondary to-primary",
      "from-accent to-secondary",
      "from-primary to-secondary",
      "from-purple-500 to-pink-600",
      "from-green-500 to-teal-600",
      "from-yellow-500 to-orange-600",
      "from-indigo-500 to-blue-600"
    ];
    return gradients[hash % gradients.length];
  };

  return (
    <Card 
      className={`method-card glass-effect transition-all duration-300 hover:transform hover:-translate-y-1 ${
        vfxEnabled ? 'hover:shadow-lg hover:shadow-blue-500/20' : ''
      }`}
      data-testid={`card-method-${method.id}`}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 bg-gradient-to-br ${getGradientClass(method.category)} rounded-full flex items-center justify-center`}>
              <i className={`${getCategoryIcon(method.category)} text-white text-sm`} />
            </div>
            <div>
              <h4 className="font-semibold text-foreground" data-testid={`text-title-${method.id}`}>
                {method.title}
              </h4>
              <p className="text-sm text-muted-foreground" data-testid={`text-author-${method.id}`}>
                By {method.author}
              </p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-accent/20 text-accent" data-testid={`badge-category-${method.id}`}>
            {method.category}
          </Badge>
        </div>
        
        <p className="text-muted-foreground mb-4" data-testid={`text-description-${method.id}`}>
          {method.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <button
              onClick={handleLike}
              className={`flex items-center space-x-1 transition-colors ${
                isLiked ? 'text-primary' : 'hover:text-primary'
              }`}
              data-testid={`button-like-${method.id}`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              <span data-testid={`text-likes-${method.id}`}>{method.likes || 0}</span>
            </button>
            <span className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span data-testid={`text-views-${method.id}`}>{method.views || 0}</span>
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleView}
            className="text-primary hover:text-primary/80"
            data-testid={`button-view-${method.id}`}
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
