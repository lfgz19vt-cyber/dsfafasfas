import { useEffect, useRef } from "react";
import { useSettings } from "@/hooks/use-settings";

interface FadingSnowflake {
  x: number;
  y: number;
  size: number;
  speed: number;
  drift: number;
  opacity: number;
  maxOpacity: number;
}

export default function ExploreSnowflakes() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const snowflakesRef = useRef<FadingSnowflake[]>([]);
  const animationFrameRef = useRef<number>();
  const { snowflakesEnabled } = useSettings();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createSnowflake = (): FadingSnowflake => {
      const maxOpacity = Math.random() * 0.4 + 0.2; // 0.2 to 0.6 opacity
      return {
        x: Math.random() * canvas.width,
        y: -10,
        size: Math.random() * 4 + 1,
        speed: Math.random() * 1.5 + 0.5,
        drift: Math.random() * 0.3 - 0.15,
        opacity: maxOpacity,
        maxOpacity,
      };
    };

    const updateSnowflakes = () => {
      if (!snowflakesEnabled) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        animationFrameRef.current = requestAnimationFrame(updateSnowflakes);
        return;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = snowflakesRef.current.length - 1; i >= 0; i--) {
        const flake = snowflakesRef.current[i];

        // Update position
        flake.y += flake.speed;
        flake.x += flake.drift;

        // Calculate fading based on position - fade more as it goes down
        const fadeProgress = flake.y / canvas.height;
        flake.opacity = flake.maxOpacity * (1 - fadeProgress * 0.8); // Fade to 20% of original

        // Draw snowflake with fading
        ctx.save();
        ctx.globalAlpha = Math.max(0, flake.opacity);
        ctx.fillStyle = 'white';
        ctx.shadowColor = `rgba(255, 255, 255, ${flake.opacity * 0.8})`;
        ctx.shadowBlur = 2;

        ctx.beginPath();
        ctx.arc(flake.x, flake.y, flake.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Remove snowflakes that are off screen or completely faded
        if (flake.y > canvas.height + 10 || flake.x < -20 || flake.x > canvas.width + 20 || flake.opacity <= 0.01) {
          snowflakesRef.current.splice(i, 1);
        }
      }

      // Add new snowflakes occasionally
      if (Math.random() < 0.2 && snowflakesRef.current.length < 150) {
        snowflakesRef.current.push(createSnowflake());
      }

      animationFrameRef.current = requestAnimationFrame(updateSnowflakes);
    };

    resizeCanvas();
    updateSnowflakes();

    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [snowflakesEnabled]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full pointer-events-none z-5"
      style={{ opacity: snowflakesEnabled ? 1 : 0 }}
      data-testid="canvas-explore-snowflakes"
    />
  );
}