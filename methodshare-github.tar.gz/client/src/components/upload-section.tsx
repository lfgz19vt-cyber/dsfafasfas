import { useState, useRef } from "react";
import { CloudUpload, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertMethodSchema, type InsertMethod } from "@shared/schema";

const recommendedCategories = [
  "EXTRNLBEAMING"
];

const contentTypes = [
  { value: 'text', label: 'Text Content', description: 'Share written tutorials, guides, or code snippets' },
  { value: 'video', label: 'Video Content', description: 'Upload video tutorials or demos' },
  { value: 'document', label: 'Document', description: 'Share PDFs, docs, or other files' },
  { value: 'image', label: 'Image Content', description: 'Share screenshots, diagrams, or visual guides' },
];

const getFileAcceptType = (contentType: string) => {
  switch (contentType) {
    case 'video':
      return 'video/*';
    case 'document':
      return '.pdf,.doc,.docx,.txt,.md';
    case 'image':
      return 'image/*';
    default:
      return '*/*';
  }
};

export default function UploadSection() {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [selectedContentType, setSelectedContentType] = useState('text');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertMethod>({
    resolver: zodResolver(insertMethodSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      author: "",
      content: "",
      contentType: "text",
      fileUrl: "",
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: InsertMethod) => {
      const response = await apiRequest("POST", "/api/methods", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/methods'] });
      form.reset();
      setUploadedFiles([]);
      toast({
        title: "Success",
        description: "Method uploaded successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload method",
        variant: "destructive",
      });
    },
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setUploadedFiles(prev => [...prev, ...files]);
    }
  };

  const onSubmit = (data: InsertMethod) => {
    // Get user profile from localStorage
    const savedProfile = localStorage.getItem('userProfile');
    const profile = savedProfile ? JSON.parse(savedProfile) : null;

    // Set author from profile or use default
    const authorName = profile?.username || profile?.name || data.author || 'Anonymous';

    uploadMutation.mutate({
      ...data,
      author: authorName
    });
  };

  return (
    <Card className="glass-effect animate-fade-in" data-testid="card-upload">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-foreground">
          Upload Your Method
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">

        {/* Content Type Selection */}
        <div className="space-y-4">
          <Label className="text-lg font-medium text-foreground">What would you like to share?</Label>
          <RadioGroup
            value={selectedContentType}
            onValueChange={(value) => {
              setSelectedContentType(value);
              form.setValue('contentType', value);
            }}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {contentTypes.map((type) => (
              <div key={type.value} className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-accent/10 cursor-pointer">
                <RadioGroupItem value={type.value} id={type.value} data-testid={`radio-content-${type.value}`} />
                <div className="flex-1">
                  <Label htmlFor={type.value} className="font-medium cursor-pointer">{type.label}</Label>
                  <p className="text-sm text-muted-foreground">{type.description}</p>
                </div>
              </div>
            ))}
          </RadioGroup>
        </div>

        {/* File Upload Area - Only show for non-text content */}
        {selectedContentType !== 'text' && (
          <div
            className={`upload-area rounded-lg p-8 text-center cursor-pointer transition-all duration-300 ${
              isDragOver ? 'drag-over' : ''
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            data-testid="area-file-upload"
          >
            <CloudUpload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-medium text-foreground mb-2">
              Drop {selectedContentType} files here or click to upload
            </p>
            <p className="text-muted-foreground">
              {selectedContentType === 'video' && 'Supports MP4, MOV, AVI and other video formats'}
              {selectedContentType === 'document' && 'Supports PDF, DOC, TXT and other documents'}
              {selectedContentType === 'image' && 'Supports JPG, PNG, GIF and other image formats'}
            </p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={handleFileSelect}
              accept={getFileAcceptType(selectedContentType)}
              data-testid="input-file"
            />
          </div>
        )}

        {/* Uploaded Files Display */}
        {uploadedFiles.length > 0 && (
          <div className="space-y-2">
            <Label>Uploaded Files:</Label>
            <div className="space-y-1">
              {uploadedFiles.map((file, index) => (
                <div key={index} className="text-sm text-muted-foreground flex items-center space-x-2">
                  <span>{file.name}</span>
                  <span className="text-xs">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Method Details Form */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Method Title</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter method title"
                        {...field}
                        data-testid="input-title"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Type your own category..."
                        {...field}
                        data-testid="input-category"
                      />
                    </FormControl>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Label className="text-xs text-muted-foreground">Recommended:</Label>
                      {recommendedCategories.map((category) => (
                        <Badge
                          key={category}
                          variant="outline"
                          className="cursor-pointer hover:bg-accent/20 text-xs"
                          onClick={() => field.onChange(category)}
                          data-testid={`badge-recommended-${category.toLowerCase()}`}
                        >
                          {category} ⚡ VIRAL
                        </Badge>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="author"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Author Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Your name"
                      {...field}
                      data-testid="input-author"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your method..."
                      rows={4}
                      className="resize-none"
                      {...field}
                      data-testid="textarea-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {selectedContentType === 'text' && (
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Write your detailed method content here..."
                        rows={8}
                        className="resize-none"
                        {...field}
                        data-testid="textarea-content"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {selectedContentType !== 'text' && (
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add any additional notes or instructions..."
                        rows={4}
                        className="resize-none"
                        {...field}
                        data-testid="textarea-content"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <div className="flex justify-end">
              <Button
                type="submit"
                className="blue-glow"
                disabled={uploadMutation.isPending}
                data-testid="button-publish"
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploadMutation.isPending ? "Publishing..." : "Publish Method"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}