import { X, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { useSettings } from "@/hooks/use-settings";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const languages = [
  { value: 'en', label: 'English' },
  { value: 'es', label: 'Español' },
  { value: 'fr', label: 'Français' },
  { value: 'de', label: 'Deutsch' },
  { value: 'zh', label: '中文' },
];

const colorSchemes = [
  { value: 'red', colors: 'from-red-600 to-red-800', label: 'Red' },
  { value: 'blue', colors: 'from-blue-600 to-blue-800', label: 'Blue' },
  { value: 'green', colors: 'from-green-600 to-green-800', label: 'Green' },
  { value: 'purple', colors: 'from-purple-600 to-purple-800', label: 'Purple' },
  { value: 'orange', colors: 'from-orange-600 to-orange-800', label: 'Orange' },
  { value: 'cyan', colors: 'from-cyan-600 to-cyan-800', label: 'Cyan' },
];

export default function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const {
    theme,
    language,
    snowflakesEnabled,
    animationsEnabled,
    vfxEnabled,
    colorScheme,
    setTheme,
    setLanguage,
    setSnowflakesEnabled,
    setAnimationsEnabled,
    setVfxEnabled,
    setColorScheme,
    resetSettings,
  } = useSettings();

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        data-testid="overlay-settings"
      />

      {/* Settings Panel */}
      <div
        className={`fixed top-0 right-0 h-full w-80 bg-card border-l border-border z-50 p-6 overflow-y-auto transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        data-testid="panel-settings"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-foreground">Settings</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            data-testid="button-close-settings"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Theme Settings */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-3 block">
              Theme
            </Label>
            <RadioGroup value={theme} onValueChange={(value: 'dark' | 'light' | 'auto') => setTheme(value)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="dark" id="dark" data-testid="radio-theme-dark" />
                <Label htmlFor="dark" className="cursor-pointer">Dark Mode</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="light" id="light" data-testid="radio-theme-light" />
                <Label htmlFor="light" className="cursor-pointer">Light Mode</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="auto" id="auto" data-testid="radio-theme-auto" />
                <Label htmlFor="auto" className="cursor-pointer">Auto</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Language Settings */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-3 block">
              Language
            </Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger data-testid="select-language">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value}>
                    {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Visual Effects */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-3 block">
              Visual Effects
            </Label>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="snowflakes">Snowflakes</Label>
                <Switch
                  id="snowflakes"
                  checked={snowflakesEnabled}
                  onCheckedChange={setSnowflakesEnabled}
                  data-testid="switch-snowflakes"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="animations">Animations</Label>
                <Switch
                  id="animations"
                  checked={animationsEnabled}
                  onCheckedChange={setAnimationsEnabled}
                  data-testid="switch-animations"
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="vfx">VFX Effects</Label>
                <Switch
                  id="vfx"
                  checked={vfxEnabled}
                  onCheckedChange={setVfxEnabled}
                  data-testid="switch-vfx"
                />
              </div>
            </div>
          </div>

          {/* Color Customization */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-3 block">
              Color Scheme
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {colorSchemes.map((scheme) => (
                <button
                  key={scheme.value}
                  onClick={() => setColorScheme(scheme.value)}
                  className={`w-full h-10 rounded-md bg-gradient-to-br ${scheme.colors} border-2 transition-colors ${
                    colorScheme === scheme.value ? 'border-primary' : 'border-transparent hover:border-primary/50'
                  }`}
                  title={scheme.label}
                  data-testid={`button-color-${scheme.value}`}
                />
              ))}
            </div>
          </div>

          {/* Preview Section */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-3 block">
              Preview
            </Label>
            <Card className="bg-muted">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="h-3 bg-primary rounded w-3/4"></div>
                  <div className="h-2 bg-accent rounded w-1/2"></div>
                  <div className="h-2 bg-secondary rounded w-2/3"></div>
                </div>
                <div className="mt-3 flex space-x-2">
                  <div className="w-8 h-8 bg-primary rounded"></div>
                  <div className="w-8 h-8 bg-accent rounded"></div>
                  <div className="w-8 h-8 bg-secondary rounded"></div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Reset Button */}
          <Button
            variant="destructive"
            onClick={resetSettings}
            className="w-full"
            data-testid="button-reset-settings"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset Settings
          </Button>
        </div>
      </div>
    </>
  );
}
