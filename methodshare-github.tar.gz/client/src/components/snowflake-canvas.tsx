import { useEffect, useRef } from "react";
import { useSettings } from "@/hooks/use-settings";

interface Snowflake {
  x: number;
  y: number;
  size: number;
  speed: number;
  drift: number;
}

export default function SnowflakeCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const snowflakesRef = useRef<Snowflake[]>([]);
  const animationFrameRef = useRef<number>();
  const { snowflakesEnabled } = useSettings();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createSnowflake = (): Snowflake => ({
      x: Math.random() * canvas.width,
      y: -10,
      size: Math.random() * 3 + 2,
      speed: Math.random() * 2 + 1,
      drift: Math.random() * 0.5 - 0.25,
    });

    const updateSnowflakes = () => {
      if (!snowflakesEnabled) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        animationFrameRef.current = requestAnimationFrame(updateSnowflakes);
        return;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'white';
      ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
      ctx.shadowBlur = 3;

      for (let i = snowflakesRef.current.length - 1; i >= 0; i--) {
        const flake = snowflakesRef.current[i];

        flake.y += flake.speed;
        flake.x += flake.drift;

        ctx.beginPath();
        ctx.arc(flake.x, flake.y, flake.size, 0, Math.PI * 2);
        ctx.fill();

        if (flake.y > canvas.height || flake.x < -10 || flake.x > canvas.width + 10) {
          snowflakesRef.current.splice(i, 1);
        }
      }

      if (Math.random() < 0.3 && snowflakesRef.current.length < 100) {
        snowflakesRef.current.push(createSnowflake());
      }

      animationFrameRef.current = requestAnimationFrame(updateSnowflakes);
    };

    resizeCanvas();
    updateSnowflakes();

    window.addEventListener('resize', resizeCanvas);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [snowflakesEnabled]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full pointer-events-none z-10"
      style={{ opacity: snowflakesEnabled ? 0.8 : 0 }}
    />
  );
}
