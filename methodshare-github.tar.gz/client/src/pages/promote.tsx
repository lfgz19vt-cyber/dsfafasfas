import { useState, useEffect } from "react";
import { ExternalLink, Check, X, Users, MessageCircle, AlertTriangle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSettings } from "@/hooks/use-settings";
import SnowflakeCanvas from "@/components/snowflake-canvas";
import { useLocation, Link } from "wouter";

function PromoteContent() {
  const [isVerified, setIsVerified] = useState(false);
  const [verificationError, setVerificationError] = useState("");
  const [user, setUser] = useState<any>(null);
  const [socialLinks, setSocialLinks] = useState<{[key: string]: string}>({});
  const { animationsEnabled } = useSettings();
  const [, setLocation] = useLocation();

  // Check authentication status on page load and from URL params
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/api/auth/status');
        const data = await response.json();

        if (data.isVerified) {
          setIsVerified(true);
          setUser(data.user);
          setVerificationError("");
        } else {
          setIsVerified(false);
          setUser(null);
        }
      } catch (error) {
        console.error('Failed to check auth status:', error);
        setIsVerified(false);
      }
    };

    // Check URL parameters for verification status
    const urlParams = new URLSearchParams(window.location.search);
    const verified = urlParams.get('verified');
    const error = urlParams.get('error');

    if (verified === 'true') {
      checkAuthStatus();
    } else if (error === 'verification_failed') {
      setVerificationError("Verification failed. Please make sure you're in the required Discord server and try again.");
    }

    // Initial check
    checkAuthStatus();
  }, []);

  const handleDiscordOAuth = () => {
    window.location.href = '/api/auth/discord';
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      setIsVerified(false);
      setUser(null);
      setVerificationError("");
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleSocialLinkChange = (platform: string, value: string) => {
    setSocialLinks(prev => ({
      ...prev,
      [platform]: value
    }));
  };

  const handleAddToProfile = async (platform: string) => {
    const link = socialLinks[platform];
    if (!link) return;

    try {
      // Here you would save to your backend
      console.log(`Adding ${platform}: ${link} to user profile`);
      // Reset the input after successful save
      setSocialLinks(prev => ({
        ...prev,
        [platform]: ""
      }));
    } catch (error) {
      console.error('Failed to save social link:', error);
    }
  };

  const socialPlatforms = [
    { name: 'Discord', icon: MessageCircle, color: 'from-indigo-600 to-purple-600', placeholder: 'Your Discord username' },
    { name: 'TikTok', icon: Users, color: 'from-black to-gray-800', placeholder: '@yourusername or TikTok URL' },
    { name: 'Instagram', icon: Users, color: 'from-pink-500 to-purple-600', placeholder: '@yourusername or Instagram URL' },
    { name: 'Twitter/X', icon: MessageCircle, color: 'from-blue-400 to-blue-600', placeholder: '@yourusername or Twitter URL' },
    { name: 'YouTube', icon: Users, color: 'from-red-600 to-red-700', placeholder: 'Channel URL or @handle' },
    { name: 'Twitch', icon: Users, color: 'from-purple-600 to-purple-800', placeholder: 'Twitch username or URL' },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SnowflakeCanvas />

      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <nav className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            <Link href="/">
              <Button variant="ghost" className="hover:bg-accent/10">
                Home
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="ghost" className="hover:bg-accent/10">
                Profile
              </Button>
            </Link>
            <Link href="/memes">
              <Button variant="ghost" className="hover:bg-accent/10">
                Memes
              </Button>
            </Link>
          </div>
          {/* Back Button is now part of the content, not navigation */}
        </nav>

        {/* Back Button */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation('/')}
            className="flex items-center gap-2 hover:bg-accent/10"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        {/* Hero Section */}
        <section className={`text-center mb-12 ${animationsEnabled ? 'animate-fade-in' : ''}`}>
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Promote Your Content
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Share your social media profiles and grow your audience
          </p>
        </section>

        {!isVerified ? (
          <div className="max-w-2xl mx-auto">
            {/* Discord Join Requirement */}
            <Card className="glass-effect mb-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Users className="w-6 h-6 text-primary" />
                  Join Our Community First
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  To access promotion features and share your social media profiles,
                  please join our Discord community first. This ensures all promoted
                  content comes from verified community members.
                </p>

                {/* Important Warning */}
                <Alert className="border-yellow-500 bg-yellow-500/10">
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription className="text-yellow-600">
                    <strong>Important:</strong> If you leave the Discord server after getting verified,
                    you will immediately lose access to all promotion features and all your promoted
                    posts will be permanently removed from the platform.
                  </AlertDescription>
                </Alert>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                    asChild
                    data-testid="button-join-discord"
                  >
                    <a href="https://discord.gg/nr3ZHqaC9s" target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Join Discord Server
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </div>

                {/* Discord OAuth Verification */}
                <div className="border-t pt-6">
                  <Label className="text-sm font-medium mb-3 block">
                    Verify your Discord account to access promotion features:
                  </Label>
                  <div className="flex justify-center">
                    <Button
                      onClick={handleDiscordOAuth}
                      size="lg"
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                      data-testid="button-verify-discord"
                    >
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Verify with Discord
                    </Button>
                  </div>

                  {verificationError && (
                    <Alert className="mt-4 border-destructive">
                      <X className="w-4 h-4" />
                      <AlertDescription>{verificationError}</AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            {/* Verification Success */}
            <Alert className="mb-8 border-green-500 bg-green-500/10">
              <Check className="w-4 h-4" />
              <AlertDescription className="text-green-600">
                <div className="flex items-center justify-between">
                  <div>
                    Discord verification successful! Welcome {user?.username}#{user?.discriminator}
                    <br />
                    <span className="text-xs text-muted-foreground mt-1 inline-block">
                      You can now promote your content.
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="text-xs"
                  >
                    Logout
                  </Button>
                </div>
              </AlertDescription>
            </Alert>

            {/* Promotion Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {socialPlatforms.map((platform) => {
                const IconComponent = platform.icon;
                return (
                  <Card key={platform.name} className="glass-effect hover:transform hover:-translate-y-1 transition-all duration-300">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-3">
                        <div className={`w-10 h-10 bg-gradient-to-br ${platform.color} rounded-full flex items-center justify-center`}>
                          <IconComponent className="w-5 h-5 text-white" />
                        </div>
                        {platform.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Input
                        placeholder={platform.placeholder}
                        value={socialLinks[platform.name] || ""}
                        onChange={(e) => handleSocialLinkChange(platform.name, e.target.value)}
                        data-testid={`input-${platform.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                      />
                      <Button
                        className="w-full"
                        onClick={() => handleAddToProfile(platform.name)}
                        disabled={!socialLinks[platform.name]?.trim()}
                        data-testid={`button-promote-${platform.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                      >
                        Add to Profile
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Instructions */}
            <Card className="glass-effect mt-8">
              <CardHeader>
                <CardTitle>How Promotion Works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Badge className="w-6 h-6 rounded-full flex items-center justify-center text-xs">1</Badge>
                      Add Your Profiles
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Enter your social media handles or URLs for each platform you want to promote.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Badge className="w-6 h-6 rounded-full flex items-center justify-center text-xs">2</Badge>
                      Get Featured
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Your profiles will be featured on your uploaded methods and in the community section.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Badge className="w-6 h-6 rounded-full flex items-center justify-center text-xs">3</Badge>
                      Grow Your Following
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Community members can discover and follow your content across platforms.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Badge className="w-6 h-6 rounded-full flex items-center justify-center text-xs">4</Badge>
                      Stay Active
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      Keep sharing quality methods to maintain your promotion visibility.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Promote() {
  return <PromoteContent />;
}