
import { useState, useRef } from "react";
import { CloudUpload, Upload, Smile, Video, Image, ArrowLeft, Heart, Eye, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/hooks/use-settings";
import { useLocation } from "wouter";
import SnowflakeCanvas from "@/components/snowflake-canvas";
import { insertMethodSchema, type InsertMethod, type Method } from "@shared/schema";

const memeTypes = [
  { value: 'video', label: 'Video Meme', description: 'TikToks, Instagram Reels, funny videos' },
  { value: 'image', label: 'Image Meme', description: 'Funny pictures, reaction memes, screenshots' },
];

function MemeCard({ meme }: { meme: Method }) {
  const [isLiked, setIsLiked] = useState(false);
  
  const handleLike = () => {
    setIsLiked(!isLiked);
    // TODO: Implement actual like functionality
  };

  return (
    <Card className="glass-effect overflow-hidden hover:scale-105 transition-transform duration-300">
      {meme.fileUrl && (
        <div className="aspect-video bg-muted relative">
          {meme.contentType === 'video' ? (
            <video 
              src={meme.fileUrl} 
              className="w-full h-full object-cover"
              controls
              poster="/api/placeholder/400/300"
            />
          ) : (
            <img 
              src={meme.fileUrl} 
              alt={meme.title}
              className="w-full h-full object-cover"
            />
          )}
        </div>
      )}
      <CardContent className="p-4">
        <h3 className="font-semibold mb-2">{meme.title}</h3>
        <p className="text-sm text-muted-foreground mb-3">{meme.description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <button 
              onClick={handleLike}
              className={`flex items-center gap-1 transition-colors ${
                isLiked ? 'text-red-500' : 'hover:text-red-500'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              {meme.likes || 0}
            </button>
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              {meme.views || 0}
            </div>
          </div>
          <Button size="sm" variant="ghost">
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function MemesContent() {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [selectedMemeType, setSelectedMemeType] = useState('video');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { animationsEnabled } = useSettings();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Load all memes
  const { data: memes = [], isLoading } = useQuery<Method[]>({
    queryKey: ['/api/methods'],
    queryFn: async () => {
      const response = await fetch('/api/methods');
      const allMethods = await response.json();
      // Filter for meme category
      return allMethods.filter((method: Method) => method.category === 'MEMES');
    },
  });

  const form = useForm<InsertMethod>({
    resolver: zodResolver(insertMethodSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "MEMES",
      author: "",
      content: "",
      contentType: "video",
      fileUrl: "",
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: InsertMethod) => {
      const response = await apiRequest("POST", "/api/methods", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/methods'] });
      form.reset();
      setUploadedFiles([]);
      toast({
        title: "Success",
        description: "Meme uploaded successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to upload meme",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setUploadedFiles(files);
    if (files.length > 0) {
      form.setValue('fileUrl', URL.createObjectURL(files[0]));
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    setUploadedFiles(files);
    if (files.length > 0) {
      form.setValue('fileUrl', URL.createObjectURL(files[0]));
    }
  };

  const onSubmit = (data: InsertMethod) => {
    uploadMutation.mutate({
      ...data,
      category: "MEMES",
      contentType: selectedMemeType,
    });
  };

  const getFileAcceptType = (memeType: string) => {
    switch (memeType) {
      case 'video':
        return 'video/*';
      case 'image':
        return 'image/*';
      default:
        return '*/*';
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SnowflakeCanvas />

      {/* Navigation */}
      <nav className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="hover:bg-accent/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Memes & Funny Content
            </h1>
            <div></div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className={`text-center mb-12 ${animationsEnabled ? 'animate-fade-in' : ''}`}>
          <div className="text-6xl mb-4">😂🎬📱</div>
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Share Your Memes
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Upload funny TikToks, Instagram Reels, reaction memes, and entertaining content
          </p>
        </section>

        {/* Upload Section */}
        <Card className="glass-effect mb-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smile className="w-6 h-6 text-primary" />
              Upload Meme
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Meme Type Selection */}
                <FormField
                  control={form.control}
                  name="contentType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meme Type</FormLabel>
                      <FormControl>
                        <RadioGroup
                          value={selectedMemeType}
                          onValueChange={(value) => {
                            setSelectedMemeType(value);
                            field.onChange(value);
                          }}
                          className="grid grid-cols-1 md:grid-cols-2 gap-4"
                        >
                          {memeTypes.map((type) => (
                            <div key={type.value} className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-accent/10">
                              <RadioGroupItem value={type.value} id={type.value} />
                              <Label htmlFor={type.value} className="flex-1 cursor-pointer">
                                <div className="flex items-center gap-2 mb-1">
                                  {type.value === 'video' ? <Video className="w-4 h-4" /> : <Image className="w-4 h-4" />}
                                  <span className="font-medium">{type.label}</span>
                                </div>
                                <p className="text-sm text-muted-foreground">{type.description}</p>
                              </Label>
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* File Upload */}
                <FormField
                  control={form.control}
                  name="fileUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Upload File</FormLabel>
                      <FormControl>
                        <div
                          className={`border-2 border-dashed rounded-lg p-8 transition-colors ${
                            isDragOver ? 'border-primary bg-primary/10' : 'border-border'
                          }`}
                          onDragOver={(e) => {
                            e.preventDefault();
                            setIsDragOver(true);
                          }}
                          onDragLeave={() => setIsDragOver(false)}
                          onDrop={handleDrop}
                        >
                          <div className="text-center">
                            <CloudUpload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                            <p className="text-lg font-medium mb-2">
                              Drop your {selectedMemeType} here or{' '}
                              <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="text-primary hover:underline"
                              >
                                browse
                              </button>
                            </p>
                            <p className="text-muted-foreground">
                              {selectedMemeType === 'video' 
                                ? 'Supports MP4, WebM, MOV files' 
                                : 'Supports JPG, PNG, GIF files'
                              }
                            </p>
                          </div>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept={getFileAcceptType(selectedMemeType)}
                            onChange={handleFileChange}
                            className="hidden"
                          />
                          {uploadedFiles.length > 0 && (
                            <div className="mt-4 p-3 bg-accent/20 rounded border-l-4 border-primary">
                              <p className="font-medium text-primary">
                                {uploadedFiles.length} file(s) selected
                              </p>
                              {uploadedFiles.map((file, index) => (
                                <p key={index} className="text-sm text-muted-foreground">
                                  {file.name}
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Give your meme a catchy title..."
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="author"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Author</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Your name or handle"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe what makes this funny..."
                          rows={4}
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end">
                  <Button
                    type="submit"
                    className="blue-glow"
                    disabled={uploadMutation.isPending}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {uploadMutation.isPending ? "Uploading..." : "Share Meme"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Memes Grid */}
        <section>
          <h2 className="text-3xl font-bold mb-6">Latest Memes</h2>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-64 bg-card animate-pulse rounded-lg"></div>
              ))}
            </div>
          ) : memes.length === 0 ? (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🎭</div>
              <p className="text-muted-foreground text-lg">
                No memes uploaded yet. Be the first to share something funny!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {memes.map((meme) => (
                <MemeCard key={meme.id} meme={meme} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default function Memes() {
  return <MemesContent />;
}
