
import { useState, useEffect } from "react";
import { User, Edit3, Upload, Heart, Eye, Calendar, Camera, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useSettings } from "@/hooks/use-settings";
import { useLocation } from "wouter";
import SnowflakeCanvas from "@/components/snowflake-canvas";
import MethodCard from "@/components/method-card";
import type { Method } from "@shared/schema";

interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  bio: string;
  avatar: string;
  joinedDate: string;
  totalMethods: number;
  totalLikes: number;
  totalViews: number;
}

function ProfileContent() {
  const [profile, setProfile] = useState<UserProfile>({
    id: "1",
    name: "",
    username: "",
    email: "",
    bio: "",
    avatar: "",
    joinedDate: new Date().toISOString().split('T')[0],
    totalMethods: 0,
    totalLikes: 0,
    totalViews: 0
  });
  const [isEditing, setIsEditing] = useState(false);
  const [, setLocation] = useLocation();
  const { animationsEnabled } = useSettings();

  // Load user's uploaded methods
  const { data: userMethods = [] } = useQuery<Method[]>({
    queryKey: ['/api/methods/user'],
    queryFn: async () => {
      const response = await fetch('/api/methods');
      const allMethods = await response.json();
      // Filter by current user - in a real app, this would be server-side
      return allMethods.filter((method: Method) => method.author === profile.username);
    },
  });

  useEffect(() => {
    // Load profile from localStorage or API
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
    }
  }, []);

  useEffect(() => {
    // Update stats based on user methods
    if (userMethods.length > 0) {
      const totalLikes = userMethods.reduce((sum, method) => sum + (method.likes || 0), 0);
      const totalViews = userMethods.reduce((sum, method) => sum + (method.views || 0), 0);
      
      setProfile(prev => ({
        ...prev,
        totalMethods: userMethods.length,
        totalLikes,
        totalViews
      }));
    }
  }, [userMethods]);

  const handleSaveProfile = () => {
    localStorage.setItem('userProfile', JSON.stringify(profile));
    setIsEditing(false);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfile(prev => ({ ...prev, avatar: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SnowflakeCanvas />

      {/* Navigation */}
      <nav className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="hover:bg-accent/10"
            >
              ← Back to Home
            </Button>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Profile
            </h1>
            <div></div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className={`glass-effect mb-8 ${animationsEnabled ? 'animate-fade-in' : ''}`}>
          <CardHeader>
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="relative">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={profile.avatar} alt={profile.name} />
                  <AvatarFallback className="text-2xl">
                    {profile.name ? profile.name.charAt(0).toUpperCase() : <User className="w-8 h-8" />}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <label className="absolute bottom-0 right-0 bg-primary text-primary-foreground rounded-full p-2 cursor-pointer hover:bg-primary/80">
                    <Camera className="w-4 h-4" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
              
              <div className="flex-1">
                {isEditing ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={profile.name}
                          onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          value={profile.username}
                          onChange={(e) => setProfile(prev => ({ ...prev, username: e.target.value }))}
                          placeholder="Your username"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profile.email}
                        onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="your.email@example.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={profile.bio}
                        onChange={(e) => setProfile(prev => ({ ...prev, bio: e.target.value }))}
                        placeholder="Tell us about yourself..."
                        rows={3}
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <h1 className="text-3xl font-bold mb-2">
                      {profile.name || "Anonymous User"}
                    </h1>
                    {profile.username && (
                      <p className="text-lg text-muted-foreground mb-2">@{profile.username}</p>
                    )}
                    {profile.bio && (
                      <p className="text-muted-foreground mb-4">{profile.bio}</p>
                    )}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Joined {new Date(profile.joinedDate).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                {isEditing ? (
                  <>
                    <Button onClick={handleSaveProfile} size="sm">
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)} size="sm">
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  </>
                ) : (
                  <Button onClick={() => setIsEditing(true)} size="sm">
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="glass-effect">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">{profile.totalMethods}</p>
                  <p className="text-muted-foreground">Methods Shared</p>
                </div>
                <Upload className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-effect">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">{profile.totalLikes}</p>
                  <p className="text-muted-foreground">Total Likes</p>
                </div>
                <Heart className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="glass-effect">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold">{profile.totalViews}</p>
                  <p className="text-muted-foreground">Total Views</p>
                </div>
                <Eye className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="methods" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="methods">My Methods</TabsTrigger>
            <TabsTrigger value="memes">My Memes</TabsTrigger>
          </TabsList>

          {/* My Methods Tab */}
          <TabsContent value="methods">
            <div className="space-y-6">
              {userMethods.length === 0 ? (
                <Card className="glass-effect">
                  <CardContent className="pt-6 text-center">
                    <Upload className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No Methods Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start sharing your knowledge by uploading your first method!
                    </p>
                    <Button onClick={() => setLocation('/')}>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Method
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userMethods.map((method) => (
                    <MethodCard key={method.id} method={method} />
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* My Memes Tab */}
          <TabsContent value="memes">
            <div className="space-y-6">
              <Card className="glass-effect">
                <CardContent className="pt-6 text-center">
                  <div className="text-6xl mb-4">😂</div>
                  <h3 className="text-xl font-semibold mb-2">No Memes Yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Upload funny TikToks, memes, and entertaining content!
                  </p>
                  <Button onClick={() => setLocation('/memes')}>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Meme
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function Profile() {
  return <ProfileContent />;
}
