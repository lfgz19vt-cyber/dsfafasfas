import { useState } from "react";
import { Search, Filter, TrendingUp, Clock, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useSettings } from "@/hooks/use-settings";
import ExploreSnowflakes from "@/components/explore-snowflakes";
import MethodCard from "@/components/method-card";
import type { Method } from "@shared/schema";
import { Link } from "wouter";

function ExploreContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"recent" | "popular">("popular");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const { animationsEnabled, setShowSettings, showSettings } = useSettings();

  const {
    data: methods = [],
    isLoading,
  } = useQuery<Method[]>({
    queryKey: searchQuery ? ['/api/methods/search', { q: searchQuery }] : ['/api/methods'],
  });

  // Get unique categories from methods
  const categories = Array.from(new Set(methods.map(method => method.category)));

  const filteredAndSortedMethods = methods
    .filter((method) => {
      if (filterCategory !== "all" && method.category !== filterCategory) return false;
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        method.title.toLowerCase().includes(query) ||
        method.description.toLowerCase().includes(query) ||
        method.category.toLowerCase().includes(query) ||
        method.author.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => {
      if (sortBy === "popular") {
        return (b.likes || 0) - (a.likes || 0);
      }
      return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
    });

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <ExploreSnowflakes />

      {/* Navigation */}
      <nav className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent cursor-pointer">
                MethodShare
              </h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" className="hover:bg-accent/10">
                  Home
                </Button>
              </Link>
              <Link href="/promote">
                <Button variant="ghost" className="hover:bg-accent/10">
                  Promote
                </Button>
              </Link>
              <Link href="/profile">
                <Button variant="ghost" className="hover:bg-accent/10">
                  Profile
                </Button>
              </Link>
              <Link href="/memes">
                <Button variant="ghost" className="hover:bg-accent/10">
                  Memes
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSettings(!showSettings)}
                className="hover:bg-accent/10"
              >
                <Settings className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className={`text-center mb-12 ${animationsEnabled ? 'animate-fade-in' : ''}`}>
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Explore Methods
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Discover amazing methods, tutorials, and guides shared by the community
          </p>
        </section>

        {/* Search and Filters */}
        <section className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex-1 w-full md:w-auto">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search methods, tutorials, guides..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10"
                  data-testid="input-explore-search"
                />
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            <div className="flex gap-3 w-full md:w-auto">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40" data-testid="select-filter-category">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex gap-2">
                <Button
                  variant={sortBy === "popular" ? "default" : "secondary"}
                  size="sm"
                  onClick={() => setSortBy("popular")}
                  data-testid="button-sort-popular"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Popular
                </Button>
                <Button
                  variant={sortBy === "recent" ? "default" : "secondary"}
                  size="sm"
                  onClick={() => setSortBy("recent")}
                  data-testid="button-sort-recent"
                >
                  <Clock className="w-4 h-4 mr-2" />
                  Recent
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Categories Overview */}
        <section className="mb-8">
          <div className="flex flex-wrap gap-2">
            <Badge
              variant={filterCategory === "all" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setFilterCategory("all")}
              data-testid="badge-filter-all"
            >
              All ({methods.length})
            </Badge>
            {categories.map((category) => (
              <Badge
                key={category}
                variant={filterCategory === category ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setFilterCategory(category)}
                data-testid={`badge-filter-${category.toLowerCase()}`}
              >
                {category} ({methods.filter(m => m.category === category).length})
                {category.toLowerCase() === 'extrnlbeaming' && ' ⚡'}
              </Badge>
            ))}
          </div>
        </section>

        {/* Results */}
        <section className={animationsEnabled ? 'animate-fade-in' : ''}>
          {searchQuery && (
            <h3 className="text-xl font-semibold mb-4">
              {filteredAndSortedMethods.length} results for "{searchQuery}"
              {filterCategory !== "all" && ` in ${filterCategory}`}
            </h3>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-48 bg-card animate-pulse rounded-lg"></div>
              ))}
            </div>
          ) : filteredAndSortedMethods.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg">
                {searchQuery || filterCategory !== "all"
                  ? 'No methods found matching your criteria.'
                  : 'No methods available yet.'
                }
              </p>
              <p className="text-muted-foreground mt-2">
                Try adjusting your search or filters.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" data-testid="grid-explore-methods">
              {filteredAndSortedMethods.map((method) => (
                <MethodCard key={method.id} method={method} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export default function Explore() {
  return <ExploreContent />;
}