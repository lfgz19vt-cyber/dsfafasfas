import { useState, useEffect } from "react";
import { Settings, Plus, ArrowUp, Flame, Clock, TrendingUp } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useSettings } from "@/hooks/use-settings";
import SnowflakeCanvas from "@/components/snowflake-canvas";
import SearchBar from "@/components/search-bar";
import MethodCard from "@/components/method-card";
import UploadSection from "@/components/upload-section";
import SettingsPanel from "@/components/settings-panel";
import type { Method } from "@shared/schema";

function HomeContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"recent" | "popular">("recent");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const { animationsEnabled } = useSettings();

  const {
    data: methods = [],
    isLoading,
    error,
  } = useQuery<Method[]>({
    queryKey: searchQuery ? ['/api/methods/search', { q: searchQuery }] : ['/api/methods'],
  });

  // Handle scroll events for scroll-to-top button
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.pageYOffset > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  const filteredAndSortedMethods = methods
    .filter((method) => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        method.title.toLowerCase().includes(query) ||
        method.description.toLowerCase().includes(query) ||
        method.category.toLowerCase().includes(query) ||
        method.author.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => {
      if (sortBy === "popular") {
        return (b.likes || 0) - (a.likes || 0);
      }
      return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
    });

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-destructive mb-2">Error Loading Methods</h2>
          <p className="text-muted-foreground">Failed to load methods. Please try again later.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SnowflakeCanvas />

      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className={`flex items-center space-x-2 ${animationsEnabled ? 'animate-slide-in' : ''}`}>
            <i className="fas fa-code text-primary text-2xl"></i>
            <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              .gg/extrnl/METH
            </h1>
          </div>

          <SearchBar
            onSearch={setSearchQuery}
            placeholder="Search methods, tutorials, guides..."
          />

          <nav className="flex items-center space-x-6">
            <Link href="/" className="nav-item text-foreground hover:text-primary transition-colors" data-testid="link-home">
              Home
            </Link>
            <Link href="/explore" className="nav-item text-foreground hover:text-primary transition-colors" data-testid="link-explore">
              Explore
            </Link>
            <Link href="/promote" className="nav-item text-foreground hover:text-primary transition-colors" data-testid="link-promote">
              <TrendingUp className="w-4 h-4 mr-1 inline" />
              Promote
            </Link>
            <Link href="/profile" className="nav-item text-foreground hover:text-primary transition-colors" data-testid="link-profile">
              Profile
            </Link>
            <Link href="/memes">
                <Button variant="ghost" className="hover:bg-accent/10">
                  Memes
                </Button>
              </Link>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsSettingsOpen(true)}
              className="text-foreground hover:text-primary hover:bg-muted"
              data-testid="button-settings"
            >
              <Settings className="w-5 h-5" />
            </Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className={`text-center mb-12 ${animationsEnabled ? 'animate-fade-in' : ''}`}>
          <h2 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Share Your Methods
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Discover and share step-by-step methods, tutorials, and guides with the community
          </p>
          <Button
            size="lg"
            className="glow-effect transform hover:scale-105 transition-all duration-300"
            data-testid="button-upload-hero"
          >
            <Plus className="w-5 h-5 mr-2" />
            Upload Method
          </Button>
        </section>

        {/* Upload Section */}
        <section className="mb-12">
          <UploadSection />
        </section>

        {/* Methods Grid */}
        <section className={animationsEnabled ? 'animate-fade-in' : ''}>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-semibold text-foreground">
              {searchQuery ? `Search Results for "${searchQuery}"` : 'Latest Methods'}
            </h3>
            <div className="flex space-x-2">
              <Button
                variant={sortBy === "popular" ? "default" : "secondary"}
                size="sm"
                onClick={() => setSortBy("popular")}
                data-testid="button-sort-popular"
              >
                <Flame className="w-4 h-4 mr-2" />
                Popular
              </Button>
              <Button
                variant={sortBy === "recent" ? "default" : "secondary"}
                size="sm"
                onClick={() => setSortBy("recent")}
                data-testid="button-sort-recent"
              >
                <Clock className="w-4 h-4 mr-2" />
                Recent
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-48 bg-card animate-pulse rounded-lg"></div>
              ))}
            </div>
          ) : filteredAndSortedMethods.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">
                {searchQuery ? 'No methods found matching your search.' : 'No methods available yet.'}
              </p>
              {!searchQuery && (
                <p className="text-muted-foreground mt-2">
                  Be the first to share a method!
                </p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="grid-methods">
              {filteredAndSortedMethods.map((method) => (
                <MethodCard key={method.id} method={method} />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-30">
        <Button
          size="icon"
          onClick={scrollToTop}
          className={`w-12 h-12 rounded-full shadow-lg glow-effect transition-all duration-300 transform hover:scale-110 ${
            showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'
          }`}
          data-testid="button-scroll-top"
        >
          <ArrowUp className="w-5 h-5" />
        </Button>
        <Button
          size="icon"
          variant="secondary"
          className={`w-12 h-12 rounded-full shadow-lg blue-glow transition-all duration-300 transform hover:scale-110 ${
            animationsEnabled ? 'animate-pulse-custom' : ''
          }`}
          data-testid="button-quick-upload"
        >
          <Plus className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}

export default function Home() {
  return <HomeContent />;
}